package com.example.myapplication;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private AndroidWebServer server;
    private TextView infoTextView;
    private TextView actionLogTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        infoTextView = findViewById(R.id.infoTextView);
        actionLogTextView = findViewById(R.id.actionLogTextView);

        // Запускаем сервер на порту 8080
        server = new AndroidWebServer(8080, this);
        try {
            server.start();
            String ip = "http://" + NetworkUtils.getLocalIpAddress(this) + ":8080";
            infoTextView.setText("Сервер запущен!\nОткройте в браузере: " + ip);
        } catch (IOException e) {
            e.printStackTrace();
            infoTextView.setText("Ошибка запуска сервера: " + e.getMessage());
        }
    }

    // Метод для обновления лога действий
    public void updateActionLog(String action) {
        String currentLog = actionLogTextView.getText().toString();
        String newLog = "Действие: " + action + "\n" + currentLog;
        actionLogTextView.setText(newLog);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (server != null) {
            server.stop();
        }
    }
}