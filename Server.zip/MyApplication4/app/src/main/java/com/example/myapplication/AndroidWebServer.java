package com.example.myapplication;

import fi.iki.elonen.NanoHTTPD;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.Map;
import java.util.HashMap;

public class AndroidWebServer extends NanoHTTPD {

    private MainActivity activity;

    public AndroidWebServer(int port, MainActivity activity) {
        super(port);
        this.activity = activity;
    }

    @Override
    public Response serve(IHTTPSession session) {
        // Убираем CORS политику
        Response response;
        String uri = session.getUri();

        if ("/action".equals(uri) && Method.POST.equals(session.getMethod())) {
            response = handleAction(session);
        } else {
            response = handleDefault();
        }

        // Добавляем CORS заголовки (разрешаем все)
        response.addHeader("Access-Control-Allow-Origin", "*");
        response.addHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
        response.addHeader("Access-Control-Allow-Headers", "Content-Type");

        return response;
    }

    private Response handleAction(IHTTPSession session) {
        try {
            // Чтение JSON из тела запроса
            Map<String, String> files = new HashMap<>();
            session.parseBody(files);
            String postData = files.get("postData");

            JSONObject request = new JSONObject(postData);
            String action = request.optString("action", "unknown");

            // Отправляем действие в MainActivity
            if (activity != null) {
                activity.runOnUiThread(() -> activity.updateActionLog(action));
            }

            // Простой ответ
            JSONObject response = new JSONObject();
            response.put("status", "success");
            response.put("action", action);

            return newFixedLengthResponse(
                    Response.Status.OK,
                    "application/json",
                    response.toString()
            );

        } catch (Exception e) {
            JSONObject error = new JSONObject();
            try {
                error.put("status", "error");
                error.put("message", e.getMessage());
            } catch (JSONException je) {}

            return newFixedLengthResponse(
                    Response.Status.INTERNAL_ERROR,
                    "application/json",
                    error.toString()
            );
        }
    }

    private Response handleDefault() {
        // Ваша HTML веб-морда
        String html = "<meta charset=\"utf-8\"><style>.btn,.btn *{-webkit-tap-highlight-color:transparent;tap-highlight-color:transparent;user-select:none;outline:none;}.d-flex,main{display:flex}.remote-body,main{justify-content:center}.btn,body{color:#fff}*{margin:0;padding:0;box-sizing:border-box}body{background:#353535;text-transform:uppercase}main{padding:15px;min-height:100vh;display:-webkit-flex;-webkit-justify-content:center;align-items:center;-webkit-align-items:center}.d-flex{display:-webkit-flex}.justify-content-between{justify-content:space-between;-webkit-justify-content:space-between}.remote-body{width:230px;height:230px;background:#111;border-radius:20px;box-shadow:0 6px 15px rgb(0 0 0 / .7);display:flex;align-items:center}img{-webkit-user-drag:none;user-drag:none;pointer-events:none}.btn{width:56px;height:56px;line-height:56px;background:#222;border:none;border-radius:50%;cursor:pointer;display:flex;display:-webkit-flex;justify-content:center;-webkit-justify-content:center;align-items:center;-webkit-align-items:center}.btn img{max-width:50%;transition:.3s ease-in-out;-webkit-transition:.3s ease-in-out}.list{margin-bottom:36px;padding:0 20px}.center-btns{width:170px;height:170px;background:#222;border-radius:50%;position:relative}.center-btns .btn{width:55px;height:55px;position:absolute}.center-btns .down,.center-btns .up{left:50%;transform:translateX(-50%);-webkit-transform:translateX(-50%)}.center-btns .up{top:1px}.center-btns .down{bottom:1px}.center-btns .left,.center-btns .right{top:50%;transform:translateY(-50%);-webkit-transform:translateY(-50%)}.center-btns .left{left:1px}.center-btns .right{right:1px}.center-btns .down img,.center-btns .right img{transform:rotate(180deg);-webkit-transform:rotate(180deg)}.center-btns .ok{width:56px;height:56px;background:#333;color:#fff;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);border-radius:50%}.down img,.up img{content:url('data:image/svg+xml;utf8,<svg width=\"36\" height=\"36\" viewBox=\"0 0 36 36\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M29.8801 22.575L20.1001 12.795C18.9451 11.64 17.0551 11.64 15.9001 12.795L6.12006 22.575\" stroke=\"%23FFF\" stroke-width=\"2\" stroke-miterlimit=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>')}.left img,.right img{content:url('data:image/svg+xml;utf8,<svg width=\"36\" height=\"36\" viewBox=\"0 0 36 36\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M33 12.51V23.49C33 25.74 30.555 27.15 28.605 26.025L23.85 23.295L19.095 20.5501C18.795 20.3701 18.555 20.175 18.36 19.935V16.0951C18.555 15.8551 18.795 15.66 19.095 15.48L23.85 12.735L28.605 10.0051C30.555 8.85006 33 10.26 33 12.51Z\" stroke=\"%23FFF\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M18.36 12.51V23.49C18.36 25.74 15.915 27.15 13.965 26.025L9.21001 23.295L4.45499 20.5501C2.50499 19.4251 2.50499 16.62 4.45499 15.48L9.21001 12.735L13.965 10.0051C15.915 8.85006 18.36 10.26 18.36 12.51Z\" stroke=\"%23FFF\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>')}</style>\n" +
                "<div style=\"transform: scale(2); transform-origin: center; width: 100vw; height: 100vh; overflow: hidden; position: fixed; top: 0; left: 0;\"><main><div class=\"d-flex justify-content-between list\"><div class=remote-body><div class=center-btns><button class=\"btn up\"><img alt=arrow></button><button class=\"btn right\"><img alt=arrow></button><button class=\"btn down\"><img alt=arrow></button><button class=\"btn left\"><img alt=arrow></button><button class=\"btn ok\"><img alt=undo src=\"\"></button></div></div></div></main></div>\n" +
                "<script>function action(action){fetch('/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:action})})\n" +
                ".then(res=>{if(!res.ok)throw new Error(`HTTP ${res.status}`);}).catch(error=>{ShowErr(`Ошибка при отправке данных (${error.message})`);});}\n" +
                "function ShowErr(e){let t=document.createElement(\"div\");t.textContent=e,t.style.position=\"fixed\",t.style.top=\"10px\",t.style.left=\"50%\",\n" +
                "t.style.transform=\"translateX(-50%)\",t.style.backgroundColor=\"#f44336\",t.style.color=\"white\",t.style.padding=\"10px 20px\",t.style.borderRadius=\"5px\",\n" +
                "t.style.boxShadow=\"0 2px 6px rgba(0,0,0,0.3)\",t.style.zIndex=1e4,document.body.appendChild(t),setTimeout(()=>{t.remove()},2e3)}</script>\n" +
                "<script>\n" +
                "const J='data:image/svg+xml;utf8,<svg width=\"36\" height=\"36\" viewBox=\"0 0 36 36\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M15.975 28.665V7.335C15.975 5.31 15.12 4.5 12.96 4.5H7.515C5.355 4.5 4.5 5.31 4.5 7.335V28.665C4.5 30.69 5.355 31.5 7.515 31.5H12.96C15.12 31.5 15.975 30.69 15.975 28.665Z\" stroke=\"%23FFF\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/><path d=\"M31.5 28.665V7.335C31.5 5.31 30.645 4.5 28.485 4.5H23.04C20.895 4.5 20.025 5.31 20.025 7.335V28.665C20.025 30.69 20.88 31.5 23.04 31.5H28.485C30.645 31.5 31.5 30.69 31.5 28.665Z\" stroke=\"%23FFF\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>';\n" +
                "function $(a,b=document){return b.querySelector(a)}\n" +
                "function on(a,b,c){a.addEventListener(b,c)}\n" +
                "on(document,'DOMContentLoaded',function(){\n" +
                "  const A=$('.up'),B=$('.right'),C=$('.down'),D=$('.left'),E=$('.ok'),I=$('img',E);\n" +
                "  I.src=J;\n" +
                "  on(A,'click',()=>action('up'));\n" +
                "  on(B,'click',()=>action('right'));\n" +
                "  on(C,'click',()=>action('down'));\n" +
                "  on(D,'click',()=>action('left'));\n" +
                "  on(E,'click', function(){\n" +
                "    action('ok');\n" +
                "    I.src.includes(\"515C5\")?I.src='data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"36\" height=\"36\" viewBox=\"0 0 36 36\" fill=\"none\"><path d=\"M10 6L28 18L10 30V6Z\" stroke=\"%23FFF\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg>':I.src=J;\n" +
                "  });\n" +
                "  document.addEventListener(\"keydown\",function(c){switch(c.key){case\"ArrowUp\":A.click();break;case\"ArrowRight\":B.click();break;case\"ArrowDown\":C.click();break;case\"ArrowLeft\":D.click();break;case\"Enter\":E.click()}});\n" +
                "});</script>";

        return newFixedLengthResponse(html);
    }
}